# Free Flow: Coding Guidelines

This document outlines the coding standards and best practices for the Free Flow iOS project. Following these guidelines ensures our codebase is readable, consistent, and maintainable.

---

## 1. File & Group Structure

Organize files logically within Xcode's project navigator. A good starting structure is:

- **App:** Contains `FreeFlowApp.swift` and `Assets`.
- **Views:** All major SwiftUI views. Sub-folders can be used for complex views (e.g., `Views/Flow/`).
    - `ContentView.swift` (Root)
    - `FlowView.swift`
    - `RhymesView.swift`
    - ...
- **Components:** Smaller, reusable views used across the app (e.g., `AnimatedBackgroundView.swift`).
- **ViewModels:** ObservableObjects that contain the business logic and state for a given view.
- **Models:** Simple data structures (`structs`) that represent the app's data (e.g., `Note`, `RhymeResult`).
- **Helpers & Extensions:** Utility functions and extensions on existing types (e.g., `Color+Extensions.swift`).

## 2. Naming Conventions

- **Types:** Use `UpperCamelCase` for all `struct`, `enum`, `class`, and `protocol` names (e.g., `FlowView`, `AudioPlayerService`).
- **Variables & Functions:** Use `lowerCamelCase` for all variable, constant, and function names (e.g., `currentKeywords`, `generateNewWords()`).
- **Booleans:** Prefix boolean variables with `is`, `has`, or `did` for clarity (e.g., `isRecording`, `hasProAccess`).
- **Views:** Suffix SwiftUI view names with `View` (e.g., `RhymesView`).

## 3. SwiftUI Best Practices

- **Break Down Views:** Avoid massive `body` properties. If a section of your view becomes complex, extract it into its own smaller, reusable subview.
- **State Management:**
    - Use `@State` only for simple, transient view-specific state (e.g., showing an alert, `searchText`).
    - Use `@StateObject` and `ObservableObject` (ViewModels) for more complex logic, state that needs to be shared, or when making network calls.
- **Use `// MARK: -`:** Organize code within your files into logical sections. This improves readability and provides quick navigation via Xcode's function menu.
    ```swift
    // MARK: - Properties
    
    @State private var searchText = ""
    
    // MARK: - Body
    
    var body: some View { ... }
    
    // MARK: - Helper Functions
    
    private func fetchRhymes() { ... }
    ```
- **Clarity over Brevity:** Write descriptive variable and function names. `generateNewKeywords()` is better than `genWrds()`.

## 4. Code Commenting

- **Explain the "Why," Not the "What":** Code should be self-documenting. Use comments to explain *why* a particular approach was taken if it's not immediately obvious.
- **Use `// TODO:`:** Mark areas that require future work. Provide a brief description of what needs to be done.
    ```swift
    // TODO: Refactor this to use an async/await pattern.
    ```

## 5. Git & Version Control

- **Branching Strategy:**
    - `main`: This branch should always be stable and reflect the code in the latest App Store release.
    - `develop`: This is the primary development branch. All feature branches are merged into `develop`.
    - `feature/...`: Create a new branch for every new feature or significant change (e.g., `feature/audio-recording`).
- **Commit Messages:** Write clear and concise commit messages. Start with a verb describing the change (e.g., "Add: RhymesView search functionality," "Fix: Crash on empty keyword list").

---
