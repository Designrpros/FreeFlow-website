# Project: Free Flow

**Tagline:** Your Digital Freestyle & Lyricism Partner

---

## 1. Core Vision & Concept

Free Flow is a minimalist yet powerful iOS application designed for rappers, poets, songwriters, and creative writers. It aims to eliminate creative friction by seamlessly blending tools for **inspiration** (random prompts, beats) and **craftsmanship** (rhyme searching, word exploration). The app's primary goal is to help users enter and maintain a state of creative "flow."

---

## 2. Target Audience

*   **Freestyle Rappers:** Seeking practice tools with beats and random prompts.
*   **Songwriters & Poets:** Needing a quick way to find rhymes, synonyms, and related concepts to perfect their lyrics.
*   **Creative Writers:** Looking for a spark to overcome writer's block.
*   **Hobbyists:** Anyone who enjoys playing with words and rhythm.

---

## 3. Core Features & App Structure

The app is built around a four-tab structure for a clean separation of concerns.

| Tab       | Purpose                                                    | Key Features                                                              |
|:----------|:-----------------------------------------------------------|:--------------------------------------------------------------------------|
| **Flow**  | Main freestyle/inspiration screen for immediate engagement.  | - Generate random keywords<br>- Play and switch instrumental beats<br>- Animated waveform visualizer<br>- One-tap audio recording                                    |
| **Rhymes**| A powerful, fast rhyming dictionary.                       | - Search for perfect rhymes<br>- Discover near/slant rhymes<br>- Group results by syllable count                                   |
| **Explore**| A thesaurus and conceptual search engine.                  | - Find synonyms and antonyms<br>- Explore conceptually related words<br>- Discover descriptive adjectives for a given noun     |
| **Notepad**| A workspace for saving and organizing ideas.               | - Save/edit text notes (lyrics)<br>- Automatically store freestyle recordings<br>- Associate text with audio recordings          |

---

## 4. Design Philosophy

*   **Minimalist & Focused:** The UI must be clean, with no unnecessary clutter, to keep the user in a creative state.
*   **Fluid & Responsive:** Animations and transitions should be smooth and immediate. The app must feel "alive."
*   **Dark-Mode First:** A dark, moody aesthetic is standard for creative apps and reduces eye strain during long sessions. The `AnimatedBackgroundView` is the foundation of this look.
*   **Frictionless:** Key actions (generating words, changing beats, recording) must be accessible with a single tap from the main screen.

---

## 5. Technology Stack

*   **Platform:** iOS
*   **Language:** Swift
*   **UI Framework:** SwiftUI
*   **Backend/APIs:**
    *   **Rhymes/Explore:** Datamuse API (free, no key required) is an excellent starting point.
    *   **Beats:** Initially local audio files bundled with the app. Future versions could stream from a server.
*   **Persistence:** `CoreData` or `SwiftData` for storing notes and recording metadata.

---

## 6. Development Roadmap

### Phase 1: Foundation (Complete)
- [x] Set up Xcode project.
- [x] Define app structure with `TabView`.
- [x] Create placeholder views for all four tabs.
- [x] Implement a unique, animated background view.
- [x] Establish project documentation (this file and coding guidelines).

### Phase 2: Core Functionality
- [ ] **Flow Tab:**
    - [ ] Implement random word generation logic.
    - [ ] Integrate an `AVAudioPlayer` to play and switch between bundled beats.
    - [ ] Animate the waveform based on audio playback (RMS/Power).
- [ ] **Rhymes & Explore Tabs:**
    - [ ] Create a network layer to fetch data from the Datamuse API.
    - [ ] Parse JSON results and display them in the lists.
    - [ ] Implement live search functionality.

### Phase 3: Refinement & Persistence
- [ ] **Notepad Tab:**
    - [ ] Set up `SwiftData` to model and persist notes.
    - [ ] Build a text editor for writing lyrics.
- [ ] **Flow Tab:**
    - [ ] Implement audio recording using `AVAudioRecorder`.
    - [ ] Save recordings and their metadata to the Notepad.
- [ ] **UI Polish:** Refine animations, add haptic feedback, and handle edge cases.

### Phase 4: Monetization & Expansion
- [ ] Implement a Freemium model (In-App Purchase).
- [ ] Add "Pro" features: more beat packs, themed word packs, audio export.
- [ ] Explore cloud sync for notes via iCloud.
